- Use "make multi" or "make serial" to create pi_multi-thread or pi_serial
- Then to run program type name of file following with the number of points.
For exam "./pi_serial 10000000"
- To delete all file .o, pi_multi-thread and pi_serial, type "make clean"
- For exercise 2, type "make code" and run "./code"